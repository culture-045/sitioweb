const express = require('express');
const morgan = require('morgan');
const path = require('path');
const flash = require('connect-flash');
const session = require('express-session');
const mySqlStore = require('express-mysql-session');
const passport = require('passport');
const cors = require('cors');
const bodyParser = require('body-parser');
const http = require('http')
const {Server} = require('socket.io')
const { engine } = require('express-handlebars');
const { defaultUser } = require('./lib/hbs-helpers')

const { database } = require('./keys_connect_db');


const app = express();
require('./lib/passport');

app.use(express.static(path.join(__dirname, 'public')));


const server = http.createServer(app)

const io = new Server(server)


app.set('port', process.env.PORT || 3898);
app.set('views', path.join(__dirname, 'views'));
app.engine(
    '.hbs',
    engine({
        defaultLayout: 'main',
        layoutsDir: path.join(app.get('views'), 'layouts'),
        partialsDir: path.join(app.get('views'), 'partials'),
        helpers: {defaultUser: defaultUser},
        extname: '.hbs'
    })
);
app.set('view engine', '.hbs');


app.use(session({
    secret: 'app-session',
    resave: false,
    saveUninitialized: false,
    store: new mySqlStore(database)
}));
app.use(flash());
app.use(morgan('dev'));
app.use(express.urlencoded({
    extended: true
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(cors());
app.use(bodyParser.json());


app.use((req, res, next) => {
    app.locals.success = req.flash('success');
    app.locals.message = req.flash('message');
    app.locals.err = req.flash('err');
    app.locals.err_ = req.flash('err_');
    app.locals.user = req.user;
    next();
})


app.use(require('./routes'));
app.use(require('./routes/authentication'));
app.use('/main', require('./routes/main'));
app.use(express.static(path.join(__dirname, './media')))



server.listen(app.get('port'), () => {
    console.log('El servidor está corriendo en el puerto ', app.get('port'));
});

require('./lib/socks')(app, io)
