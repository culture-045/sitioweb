module.exports = {
    database: {
        host: 'localhost',
        user: 'root',
        password: '2004',
        database: 'database_back'
    }
}
