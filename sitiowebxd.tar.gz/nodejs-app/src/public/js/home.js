
$(document).ready(() => {
    $('main').fadeIn(1500)
    $('main').css("display", "flex")
});

const targets = document.querySelectorAll('[data-target]');
const content = document.querySelectorAll('[data-content]');

function viewUsers() {
    let cliked = document.querySelector('.foc');
    cliked.addEventListener('click', () => {
        const usersel = users.username;
        console.log(usersel);
    })
}
function getUsersnames() {
    fetch("http://localhost:3898/request")
    .then(gente => gente.json())
    .then(usuarios => {
        let contentainerUsers = document.querySelector('.containerUsers');

        for (const users of usuarios) {
            let campo = `
                <form class="form-btn" action="/main/profileuser/${users.username}" method="post">
                    <button class="foc">${users.username}</button>
                </form>
        `
            contentainerUsers.innerHTML += campo;

        }
    })
}
if (document.querySelector('.containerUsers')) {
    getUsersnames();
}

function getInfoUser() {
    fetch('http://localhost:3898/main/userinfo')
        .then(username => username.json())
        .then(showInfo => {

            let containerInfo = document.querySelector('.container__user_info')

            let colum = `<p>Nombre: ${Object.values(showInfo[0])[0]}</p>
            <p>Nombre de Usuario: ${Object.values(showInfo[0])[1]}</p>
            `

            containerInfo.innerHTML += colum;
            console.log(Object.values(showInfo[0])[0])
        })
}
if (document.querySelector('.container__user_info')) {
    getInfoUser();
}

targets.forEach(target => {
    target.addEventListener('click', () => {
        const tags = document.querySelectorAll('[data-target]');
        tags.forEach(tag => {
            tag.classList.remove('focus')
        })
        content.forEach(c => {
            c.classList.remove('active');
        })
        const t = document.querySelector(target.dataset.target);
        t.classList.add('active');
        target.classList.add('focus');
    })
})

