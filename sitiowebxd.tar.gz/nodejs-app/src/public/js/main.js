$(
    () => {
        $('#input_a').focus(() => {
            $('.sublinea').css("width", "100%")
        })
        $('#input_a').focusout(() => {
            $('.sublinea').css("width", "0")
        })
        $('#input_b').focus(() => {
            $('.subline').css("width", "100%")
        })
        $('#input_b').focusout(() => {
            $('.subline').css("width", "0")
        })
        $('#input_c').focus(() => {
            $('.sublinec').css("width", "100%")
        })
        $('#input_c').focusout(() => {
            $('.sublinec').css("width", "0")
        })
    }
)
