$(
    () => {
        if (window.location.pathname === '/signup') {
            $('.i-signup').addClass('pag__act');
        } else if (window.location.pathname === '/signin') {
            $('.i-signin').addClass('pag__act');
        } else if (window.location.pathname === '/home') {
            $('.i-home').addClass('pag__act');
        } else if (window.location.pathname === '/profile') {
            $('.i-profile').addClass('pag__act');
        } else if (window.location.pathname === '/rice') {
            $('.i-rice').addClass('pag__act');
        } else if (window.location.pathname === '/panelcontrol') {
            $('.i-panel').addClass('pag__act');
        }

    
    }
)
