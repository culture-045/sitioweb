
/* const socket = io();

socket.on('culo', data => {
    console.log(data);
}) */
