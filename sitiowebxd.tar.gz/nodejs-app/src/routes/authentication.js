const express = require('express');
const router = express.Router();
const passport = require('passport');
const { isLoggedIn, isNotLoggedIn } = require('../lib/auth');


router.get('/signin', isNotLoggedIn, (req, res) => {
    res.render('auth/signin');
});

router.get('/signup', isNotLoggedIn, (req, res) => {
    res.render('auth/signup');
});

router.get('/profile', isLoggedIn, (req, res) => {
    res.render('profile');
});

router.get('/home', isLoggedIn, async (req, res) => {
    res.render('layouts/home');
});

router.get('/panelcontrol', isLoggedIn, (req, res) => {
    res.render('layouts/panelcontrol')
})

/* router.get('/foro', isLoggedIn, (req, res) => {
    res.render('main/foro')
}) */

router.get('/logout', isLoggedIn, (req, res) => {
    req.logout(req.user, err =>{
        if (err) return next(err);
        res.redirect('/signin');
    });
});



router.post('/signin', isNotLoggedIn, (req, res, next) => {
    passport.authenticate('local.signin', {
        successRedirect: '/home',
        failureRedirect: '/signin',
        failureFlash: true
    })(req, res, next);
});

router.post('/signup', isNotLoggedIn, passport.authenticate('local.signup', {
    successRedirect: '/home',
    failureRedirect: '/signup',
    failureFlash: true
}));


module.exports = router;
