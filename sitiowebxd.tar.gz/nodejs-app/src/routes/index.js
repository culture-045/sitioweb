const express = require('express');
const path = require('path')
const router = express.Router();
const pool = require('../database_connect');
const multer = require('multer');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../media/prf_photos'))
    },
    filename: (req, file, cb) => {
        cb(null, `image-${Date.now()}.${file.mimetype.split('/')[1]}`)
    }
})
const upload = multer({ storage: storage })
const host = 'http://localhost:3898';

router.get('/', (req, res) => {
    res.render('index');
});

router.get('/request', async (req, res) => {
    const gente = await pool.query('SELECT id, username, fullname FROM users');
    res.json(gente)
})

router.post('/profile/change_username/:username', async (req, res) => {
    const { username } = req.params;
    const newUsername = Object.values(req.body);
    await pool.query('UPDATE users SET username=? WHERE username = ?', [newUsername, username])
    res.redirect('/profile')
})
router.post('/profile/change_fullname/:username', async (req, res) => {
    const { username } = req.params;
    const newFullname = Object.values(req.body);
    await pool.query('UPDATE users SET fullname=? WHERE username = ?', [newFullname, username])
    res.redirect('/profile')
})
router.post('/profile/change_bio/:username', async (req, res) => {
    const { username } = req.params;
    const newBio = Object.values(req.body);
    await pool.query('UPDATE users SET description=? WHERE username = ?', [newBio, username])
    res.redirect('/profile')
})
router.post('/profile/change_photo/:username', upload.single('photo_changed'), async (req, res) => {
    const { username } = req.params
    const url_photo = `${host}/prf_photos/${req.file.filename}`;
    await pool.query('UPDATE users SET photo_profile=? WHERE username = ?', [url_photo, username])
    res.redirect('/profile')
    //res.json({msg: 'listo'})
})

module.exports = router;
