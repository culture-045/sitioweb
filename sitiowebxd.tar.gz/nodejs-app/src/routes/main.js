const express = require('express');
const router = express.Router();
const pool = require('../database_connect');
const { isLoggedIn, isNotLoggedIn } = require('../lib/auth');

router.get('/help', (req, res) => {
    res.send('hola')
});

router.post('/profileuser/:username', isLoggedIn,async (req, res) => {
    const { username } = req.params;
    res.render('layouts/profileuser')
    const info = await pool.query('SELECT fullname, username FROM users WHERE username = ?', username)
    if (username) {
        router.get('/userinfo', isLoggedIn, async (req,res) => {
            res.json(info);
        })
    }
})

module.exports = router;
